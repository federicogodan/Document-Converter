require 'spec_helper'

describe NotificationController do

end
