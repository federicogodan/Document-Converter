require 'spec_helper'

describe "admin_default_values/post.html.erb" do
  pending "add some examples to (or delete) #{__FILE__}"
end
