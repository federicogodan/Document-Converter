class DocsController < ApplicationController
  def index
  end
end
