require 'spec_helper'

describe Whsent do
  pending "add some examples to (or delete) #{__FILE__}"
end
