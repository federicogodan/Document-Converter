require 'spec_helper'

describe Api::ApiController do

end
