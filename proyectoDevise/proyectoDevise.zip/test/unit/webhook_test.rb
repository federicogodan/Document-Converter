require 'test_helper'

class WebhookTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
