require 'test_helper'

class User::SessionsHelperTest < ActionView::TestCase
end
