require 'test_helper'

class DocumentsFileTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
