# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
ProyectoDevise::Application.config.secret_token = '153c8fd6f6398d8e040eba3c7835193106b343e6b5cba5586e3ce589a72fa39fc54629e2f8ec7f3ad5a10ef1a947f10cca8f7f2b0d2857fcfc6bf3e75345a8ed'
