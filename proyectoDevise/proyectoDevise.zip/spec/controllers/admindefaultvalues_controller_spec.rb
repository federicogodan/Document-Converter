require 'spec_helper'

describe AdmindefaultvaluesController do

end
