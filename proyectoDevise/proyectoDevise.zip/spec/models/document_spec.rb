require 'spec_helper'

describe Document do
  pending "add some examples to (or delete) #{__FILE__}"
end
