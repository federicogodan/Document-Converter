ActiveAdmin.register_page "DefaultValues" do
  menu :priority => 2
  
  content :title => "Edit default values" do
    render "page"
  end
  
end